const api = require('./server');
api.start();
