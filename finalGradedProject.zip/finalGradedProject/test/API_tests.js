const chai = require('chai');
const chaiHTTP = require('chai-http');
const { response } = require('express');
const api = require('../server');
const { v4: uuidv4 } = require('uuid');
const bCrypt = require('bcryptjs');
chai.use(chaiHTTP);

const expect = chai.expect;
const apiAddress = 'http://localhost:12345';

const test_str = uuidv4();
const test_id = '123456789';

describe('Test operations', function(){

    before(function() {
        api.start();
    })

    after(function() {
        api.stop();
    })

    describe('Should register a new user', function(){
        it('Should add a user', async function() {
            await chai.request(apiAddress)
            .post('/registration')
            .send({
                fullName: 'Example',
                birthDate: '2020-10-14',
                eMail: 'example@email.com',
                userName: 'NewNamNam',
                passWord: bCrypt.hashSync('newPassword')
            })
            .then(response => {
                expect(response.status).to.equal(200);
                return chai.request(apiAddress).get('/registration');
            })
            .catch(error => {
                expect.fail(error);
            })
        })

    });

    describe('Should create a new posting', function() {
        it('Adds a new posting', async function() {
            await chai.request(apiAddress)
            .post('/posting')
            .auth('NamNam', 'examplePassWord')
            .send(
                {
                title: 'A new salable',
                description: 'A brand new salable',
                category: 'New Salables',
                images: {
                    imageOneURL: "",
                    imageTwoURL: "",
                    imageThreeURL: "",
                    imageFourURL: ""
                },
                askingPrice: 9.99,
                postDate: '2020-10-14',
                location: {
                    town: "AnotherTown",
                    country: "AnotherCountry",
                    address: "AnotherAddress",
                    zipCode: "AnotherZipCode"
                },
                seller: {
                    sellerName: "AnotherSeller",
                    eMail: "AnotherEmail@example.com",
                    phoneNumber: "1111111111111"
                },
                postingID: test_id,
                pickUpDel: false,
                deliveryDel: false
            })
            .then(response => {
                expect(response.status).to.equal(200);
                return chai.request(apiAddress).get('/posting');
            })
            .catch(error => {
                expect.fail(error);
            })
        })
    });

    describe('Should be able to modify postings', function(){
        it('Modifies a certain posting', async function() {
            await chai.request(apiAddress)
            .put('/posting/ddeb46cc-6dc4-4cb0-9f7e-d3ac7b97d0a4')
            .auth('NamNam', 'examplePassWord')
            .send({
                title: "testing"
            })
            .then(response => {
                expect(response.status).to.equal(200);
            })
            .catch(error => {
                expect.fail(error);
            })
        })
    })

    describe('Should be abe to delete user', function() {
        it('Delete user', async function() {
            await chai.request(apiAddress)
            .delete('/posting/ddeb46cc-6dc4-4cb0-9f7e-d3ac7b97d0a5')
            .auth('NamNam', 'examplePassWord')
            .then(response => {
                expect(response.status).to.equal(200);
            })
        })
    })

    describe('Should be able to search by category', function() {
        it('Search by category', async function() {
            await chai.request(apiAddress)
            .get('/posting/searchByCategory/Random')
            .then(response => {
                expect(response.status).to.equal(200);
                expect(response.body).to.be.a('array');
            })
            .catch(error => {
                expect.fail(error);
            })
        })
    })
    describe("Should be able to search by location", function() {
        it('Search by location', async function() {
            await chai.request(apiAddress)
            .get('/posting/searchByLocation/TheTown')
            .then(response => {
                expect(response.status).to.equal(200);
                expect(response.body).to.be.a('array');
            })
            .catch(error => {
                expect.fail(error);
            })
        })
    })
    describe("Should be able to search by date", function() {
        it('Search by date', async function() {
            await chai.request(apiAddress)
            .get('/posting/searchByDate/2020-10-12')
            .then(response => {
                expect(response.status).to.equal(200);
                expect(response.body).to.be.a('array');
            })
            .catch(error => {
                expect.fail(error);
            })
        })
    })

})