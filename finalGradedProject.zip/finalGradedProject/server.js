
const express = require('express')
const bodyParser = require('body-parser');
const { v4: uuidv4 } = require('uuid');
const { query, response } = require('express');
const { json } = require('body-parser');
const bcrypt = require('bcryptjs');

const app = express()
const port = 12345

app.use(bodyParser.json());
const passport = require('passport');
const BasicStrategy = require('passport-http').BasicStrategy;

let newArray = []

let userInfo = [ 
  {
  fullName: 'Name Namersson',
  birthDate: '2020-10-12',
  eMail: 'example@examplemail.com',
  userName: 'NamNam',
  passWord: bcrypt.hashSync('examplePassWord')
  }
];


app.post('/registration', (req, res) => {

  try {
      const newUser = {
      fullName: req.body.fullName,
      birthDate: req.body.birthDate,
      eMail: req.body.eMail,
      userName: req.body.userName,
      passWord: bcrypt.hashSync(req.body.passWord)
    };

    userInfo.push(newUser);
    res.sendStatus(200);

  } catch (error) {
    res.sendStatus(400);
  }
})

let posting = [
  {
  title: "Item one",
  description: "This item is for sale for reasonable price",
  category: "Random",
  images: {
    imageOneURL: "",
    imageTwoURL: "",
    imageThreeURL: "",
    imageFourURL: ""
  },

  askingPrice: 0.00,
  postDate: "2020-10-12",
  location: {
    town: "TheTown",
    country: "TheCountry",
    address: "TheStreet1",
    zipCode: "0000"
  },

  seller: {
    sellerName: "Seller",
    eMail: "email@example.com",
    phoneNumber: "0000000000000"
  },
  //postingID: uuidv4(),
  postingID: 'ddeb46cc-6dc4-4cb0-9f7e-d3ac7b97d0a4',
  pickUpDel: false,
  deliveryDel: false,
}
];

app.post('/posting',
passport.authenticate('basic', { session: false }), (req, res) => {

  try {
      const newPosting = {
      title: req.body.title,
      description: req.body.description,
      category: req.body.category,
      images: req.body.images,
      askingPrice: req.body.askingPrice,
      postDate: req.body.postDate,
      location: req.body.location,
      seller: req.body.seller,
      //postingID: uuidv4(),
      postingID: 'ddeb46cc-6dc4-4cb0-9f7e-d3ac7b97d0a5',
      pickUpDel: req.body.pickUpDel,
      deliveryDel: req.body.deliveryDel
  };

  posting.push(newPosting);
  res.sendStatus(200);

  } catch (error) {
    res.sendStatus(400);
  }
})

app.get('/posting', (req, res) => {
    res.json({posting});
})

app.put('/posting/:postingID',
passport.authenticate('basic', { session: false }), (req, res) => {
  const result = posting.find(t => t.postingID == req.params.postingID);
  if (result !== undefined)
  {
      for (const key in req.body) {
          result[key] = req.body[key]
      }
      res.sendStatus(200);

  } else {
      res.sendStatus(404);
  }
})

app.delete('/posting/:postingID',
passport.authenticate('basic', { session: false }), (req, res) => {
  const result = posting.findIndex(t => t.postingID == req.params.postingID); 
  if (result !== -1){

      posting.splice(result, 1);
      res.sendStatus(200);

  } else {
      res.sendStatus(404);

  }
})
//Searching by category means that you have to serach by existing category, you've put in one of the new postings.

app.get('/posting/searchByCategory/:category', (req, res) => {
  const anotherResult = posting.find(t=> t.category === req.params.category);

  if (anotherResult !== undefined){

      for (x = 1; x < posting.length; x++){
        if (posting[x] === anotherResult){
          var ind = posting[x];
          newArray.push(ind);
        } 
      }
      res.json(newArray);
      res.sendStatus(200);

    } else{
      res.sendStatus(404);
    }

})

//For the purposes of this API and assigment, I ended up deciding that one should only
//be able to serach based on town's name, you put into the API

app.get('/posting/searchByLocation/:town', (req, res) => {
  let locationArray = [];

  const town = posting.find(townEl => townEl.location.town === req.params.town) || 'all';

  if (town !== undefined){

    for (x = 1; x < posting.length; x++){
        if (posting[x] === town);
        var ind = posting[x];
        locationArray.push(ind);
      //locationArray.push(town);
        
    }
      res.json(locationArray);
      res.sendStatus(200);

    } else{
      res.sendStatus(404);
    }
})

//Posting date has to be searched by using YYYY-MM-DD (Year-month-day)

app.get('/posting/searchByDate/:postDate', (req, res) => {
  let dateArray = []
  const dateResult = posting.find(delm=> delm.postDate === req.params.postDate);

  if (dateResult !== undefined){

      for (y = 1; y < posting.length; y++){
        if (posting[y] === dateResult){
          var ind = posting[y];
          dateArray.push(ind);
        }

      }
      res.json(dateArray);
      res.sendStatus(200);

    } else{
      console.log("Something went wrong");
      res.sendStatus(404);
    }
})


passport.use(new BasicStrategy(
  function(username, password, done) {

    const user = userInfo.find(el => el.userName === username);

    if(user == undefined) {
      // Username not found
      console.log("HTTP Basic username not found");
      return done(null, false, { message: "HTTP Basic username not found" });
    }

    /* Verify password match */
    if(bcrypt.compareSync(password, user.passWord) == false) {
      // Password does not match
      console.log("HTTP Basic password not matching username");
      return done(null, false, { message: "HTTP Basic password not found" });
    }
    return done(null, user);
  }
));

app.get('/httpBasicProtectedResource',
        passport.authenticate('basic', { session: false }),
        (req, res) => {
  res.json({
    yourProtectedResource: "profit"
  });
});


let api_instance = null;
exports.start = () =>{
    api_instance = app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})
}

exports.stop = () => {
    api_instance.close();
}